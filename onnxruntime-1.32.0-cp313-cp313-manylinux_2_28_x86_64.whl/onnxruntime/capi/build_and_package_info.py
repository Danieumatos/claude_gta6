package_name = 'onnxruntime'
__version__ = '1.32.0'
